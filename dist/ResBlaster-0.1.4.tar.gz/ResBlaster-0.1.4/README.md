# ResBlaster


## Installation
pip3 install ResBlaster==0.1.3

## Dependency
- BLAST+ >2.7.0
- cvmblaster (v0.1.3)


