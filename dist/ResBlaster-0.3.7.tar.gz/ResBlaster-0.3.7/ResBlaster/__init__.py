# -*- coding:utf-8 -*-

__title__ = 'ResBlaster'
__description__ = 'gene analysis'
__url__ = 'https://github.com/hbucqp/ResBlaster'
__version__ = "0.3.7"
__author__ = 'Qingpo Cui'
__author_email__ = 'cqp@cau.edu.cn'
__license__ = 'MIT'
__copyright__ = 'Copyright 2022 Qingpo Cui'
